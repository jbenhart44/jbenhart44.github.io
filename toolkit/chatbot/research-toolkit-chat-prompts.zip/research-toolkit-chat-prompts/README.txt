Research Amp Toolkit: prompts for an ordinary chatbot
https://jbenhart44.github.io/toolkit/#chatbot

Open a prompt file, copy all of it into a new chat (or attach the file), and give the chatbot your
material when it asks. Each prompt starts with rules for working in a chat.

Not sure where to start? Use help.txt.
coa.txt, pace.txt and quarto.txt are the longest; if a chat will not take one, attach the file instead.

The tools were written for Claude Code and tested with Claude models. You can paste the
prompts into ChatGPT, Gemini, Copilot or any other assistant. A few lines still name Claude
Code or a Claude account. Their results there have not been measured, so check what comes back.

Works in a Chat
---------------
help.txt  /help: Describe your situation in one line and it names the tool to use. It may name a tool that needs Claude Code; the toolkit page and the README in the ZIP list the tools that work in a chat.
quick-ten.txt  /quick-ten: Describe what you are about to build. It asks the few questions whose answers change the build, then writes a short brief.
simplify.txt  /simplify: Paste the code or the document. It reviews it for redundancy and complexity and proposes simpler versions; it cannot run your tests, so run them yourself before you keep a change.

Works in a Chat, with Limits
----------------------------
audit.txt  /audit: Paste the document and the text of each source. It checks each cited number against the text you pasted; a source you do not paste is reported as not on file, never as checked.
bulletproof.txt  /bulletproof: Paste the code. It writes the tests and the planted defects; you run them and paste the results back, because it cannot run anything.
coa.txt  /coa: Useful for structured disagreement on a decision. One chatbot plays every council member and the Chair who sums them up, so the members are not independent and their agreement is weak evidence. It cannot read your files: paste the evidence each member should use.
list-maker.txt  /list-maker: Paste a transcript. It writes the numbered, tiered list. It cannot keep the ledger file, so save the list it gives you and paste it back next time to keep the numbers.
meeting-breakdown.txt  /meeting-breakdown: Paste the transcript. One chatbot plays the five agents in turn, so the review steps are not independent. It writes the per-domain plan in the chat rather than beside the transcript.
pace.txt  /pace: Gives you two framings of a task and a review of each. One chatbot writes both framings and both reviews, so their agreement proves little. Paste the task and any source it must check against.
quarto.txt  /quarto: Paste your notes. It drafts the Quarto source for the deck; you render it yourself with Quarto installed.
review.txt  /review: Paste the document. One chatbot reads it through all three lenses in turn, so the lenses are not independent readers.
step-by-step.txt  /step-by-step: Paste the list of changes (for example the output of git log --oneline) or a numbered work list. It walks it one item per turn and tracks which items are left.

Needs Claude Code (No Prompt Here)
----------------------------------
/acquire: It downloads and extracts files with a script. In a chat, attach the paper and use /audit with its text.
/automate: It writes a Claude Code skill and script from your session's history.
/commit: It reads and writes your git repository.
/daily-summary: It builds the summary from your git history and the files the session changed.
/guard-hook: It builds and tests Claude Code hooks.
/improve: It audits the Claude Code setup on your machine.
/pcv: PCV is a multi-file protocol that runs scripts in your project. Its method is described at https://mgkay.github.io/pcv/.
/readable: It writes text files beside your PDFs for later searches. A chatbot reads an attached PDF directly.
/run-log: It reads the run logs other commands write on disk.
/setup: It writes the Claude Code config file the other commands read.
/startup: It reads your project's summaries and git history on disk.
/weekly-summary: It aggregates the daily summary files in your project.
