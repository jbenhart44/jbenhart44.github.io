# Design Rationale — Research Amp Toolkit

**Version:** 2.0.0
**Date:** 2026-10-19 (v2.0 adds `/setup`, the release gates and the usage counter; see the changelog at the bottom)
**Author:** Jake Benhart. `/pcv` (Plan-Construct-Verify), bundled in `pcv/`, is the work of Dr. Michael G. Kay.

This document records every significant design decision in the toolkit: what was chosen, what was rejected, and why. It serves as the authoritative reference when evaluating proposed additions or changes.

---

## Core Principle: Simplest Model That Works

This toolkit applies Occam's razor to AI-assisted research workflows:

> **Include the minimum set of commands that covers the three gaps (verification, planning, documentation). Reject any addition that duplicates existing capability, requires untested infrastructure, or increases the install surface without proportional value.**

The test for inclusion is: *Would a PhD student doing computational research use this command at least weekly?* If not, it's either a v2+ candidate or a teaching guide topic — not a command.

### What "Simplest" Means in Practice

- **One command per function.** If `/pace` already does grading verification, we don't add `/grading-rubric`. If `/improve` already audits infrastructure, we don't add `/research-audit`.
- **Same commands for all users.** Student and instructor toolkits differ in *which* commands are installed, not in command behavior. Context comes from teaching guides, not per-persona command variants.
- **Configuration over code.** Project-specific behavior lives in `toolkit-config.md`, not in command logic. Commands read the config; they don't branch on audience type.
- **Guides over tools for policy.** PII handling, academic integrity, and IRB compliance are policy decisions — they belong in teaching guides with stern notes, not in commands that give false confidence.

---

## Command Inventory (v1.0)

### Why 15 Commands

The toolkit started with 15 commands built during PhD research. Assessment:

| Tier | Commands | Disposition |
|------|----------|-------------|
| **Tier 1 — Showcase** | /pcv, /coa, /pace, /improve, /simplify | Core methodology — included |
| **Tier 2 — Workflow** | /startup, /dailysummary, /weeklysummary, /commit, /runlog | Daily-use productivity — included |
| **Tier 3 — Content** | /quarto, /readable | Document generation — included |
| **Tier 4 — Triage** | /help | Discoverability triage — added v1.3 |
| **Tier 5 — Verification** | /audit, /review | Citation + document review — added v1.0 (audit) / v1.4 (review) |
| **Excluded** | 4 domain-specific commands | Not generalizable beyond the original research context |

15 user-visible commands = 14 command files in `shared/commands/` (one .md per slash-command) + `/pcv` registered via the skills registry. Growth history: /audit added 2026-04-03 after catching 4 numerical mismatches on a dissertation poster (citation verification became non-negotiable); /runlog added v1.1 for longitudinal observability; /help added v1.3 on 2026-04-19 for the paradox-of-choice problem a growing command list creates; /review added v1.4 for three-lens document reading. A research instrument (/pcv-research) was previously bundled but was removed on 2026-04-10 after empirical testing revealed its hierarchical subagent spawning architecture is incompatible with Claude Code's tool model; it is held back pending further redesign and is no longer shipped.

**As of v2.0: 16 commands** (15 command files + `/pcv`). `/setup` was added so that no command carries one author's folders, workstreams or habits as defaults: it asks, and writes the answers to `toolkit-config.md`.

### Persona-Command Mapping

| Command | Instructor (`--minimal`) | Student (full) | Layer |
|---------|:---:|:---:|---|
| /setup | Yes | Yes | Configuration |
| /pcv | Yes | Yes | Verification |
| /coa | Yes | Yes | Verification |
| /pace | Yes | Yes | Verification |
| /improve | Yes | Yes | Verification |
| /review | Yes | Yes | Verification |
| /help | Yes | Yes | Triage |
| /quarto | Yes | Yes | Content |
| /readable | Yes | Yes | Content |
| /startup | — | Yes | Workflow |
| /dailysummary | — | Yes | Workflow |
| /weeklysummary | — | Yes | Workflow |
| /commit | — | Yes | Workflow |
| /simplify | — | Yes | Workflow |
| /audit | — | Yes | Verification |
| /runlog | — | Yes | Verification |

**Instructor gets 9, student gets 16.** The split logic:
- Instructors need verification tools (teach methodology), the triage entry-point (/help), and content tools (create materials).
- Students also need workflow tools (build research habits: daily documentation, session continuity, clean commits, longitudinal evidence via /runlog).

---

## Tradeoff Log

### Accepted into v1.0

| Decision | Rationale |
|----------|-----------|
| **Bundle PCV v3.14 directly** | Users need it to work immediately. Linking to Kay's repo adds a dependency and version-sync risk. We distribute as-is; improvements go upstream. Refresh cadence managed by `scripts/refresh-pcv-bundle.sh` with `scripts/check-pcv-upstream.sh` drift detection. |
| **Config-file generalization** | Every command that needs project context reads `toolkit-config.md`. Zero hardcoded project paths in any command file. Verified via SC3 grep (Session 1). |
| **Dual installer** | `install.sh` (shell) for terminal users, `bootstrap.md` (Claude Code agent) for in-session install. Two paths to the same result — meets users where they are. |
| **Sonnet recommended, not required** | Academic users have varying model access. Hard Sonnet mandate blocks Haiku-only users. Fallback: "verify numbers manually if Sonnet unavailable." |
| **Teaching guides over command variants** | Three instructor guides (PCV for courses, CoA for discussion, PACE for grading) provide pedagogical context. The commands themselves stay generic. |
| **Inline config examples** | Commented-out examples in `toolkit-config.md` (research project + graduate course) show users what a filled-in config looks like. Lower friction than a separate examples/ directory. |

### Rejected from v1.0 (with reasoning)

| Proposal | Source | Why Rejected | Disposition |
|----------|--------|-------------|-------------|
| `/sanitize` or `/privacy-check` | Gemini | PII scanning is a hard problem. Existing tools (Presidio, detect-secrets) do it better than a command file. A command that misses a student ID is worse than no command — it creates false confidence. | **Policy note in instructor guide.** |
| `/study-breakdown` | Gemini | Turns syllabi into study plans. Requires classroom testing to validate. Zero evidence it works. Premature implementation. | **v2+ backlog.** |
| `/integrity-check` | Gemini | Audits student work against CoV protocol. Interesting concept but undefined scope — what exactly does "integrity" mean algorithmically? Needs design research first. | **v2+ backlog.** |
| `/grading-rubric` | Gemini | Generates feedback from rubric. `/pace` already does this — the `using-pace-for-grading.md` guide teaches exactly this workflow. Redundant. | **Already covered by /pace + guide.** |
| `/research-audit` | Gemini | Verifies TA work followed phase gates. `/improve` already audits infrastructure. Adding a TA-specific wrapper is a "skin command" — same engine, different label. | **Already covered by /improve.** |
| `/cite` or `/bib` | Gemini | BibTeX parsing, DOI resolution, PDF matching — each is a deep rabbit hole. Our citation tier system works because it's enforced by CLAUDE.md rules, not a separate tool. A half-built citation manager is worse than no citation manager. | **v3+ backlog (if ever).** |
| **Per-persona command variants** | Gemini | Student `/coa` vs. instructor `/coa` with different defaults. Doubles the maintenance surface. Commands are generic; context comes from guides and config. | **Rejected permanently.** |
| **NC State theme bundling** | Internal | University brand assets (SCSS, logos) don't belong in a public MIT-licensed repo. Users bring their own themes. | **BYOT (Bring Your Own Theme).** |
| **Project-specific safety hooks** | Internal | Hooks enforcing project-specific rules (protected files, commit policies) are safety nets tied to a particular workflow. Generic users don't have the same protected files. | **From v2.2.0: shipped as a mechanism with no list in it.** `protect_files` reads what it protects from the user's `~/.claude/toolkit-config.md`; an empty config allows everything; the installer copies it with `--hooks` and never registers it; it has a self-test and a mutation check. *(Until v2.2.0 this cell read: "Not bundled. Generic utility hooks (token budget, folder guard) are shipped as optional opt-in via `--hooks` flag.")* |
| **ECL-lite scorecard system** | Internal | Council session scoring requires infrastructure (scorecard templates, precedent index) that most users don't need. Adds complexity for a niche use case. | **v2+ backlog.** |
| **PRECEDENT_INDEX session tracking** | Internal | Cumulative CoA session history is valuable for longitudinal research but adds file management overhead. Most users run CoA for one-off questions, not multi-session analysis. | **v2+ backlog.** |
| **Per-task-type cost benchmarks** | Internal | Token cost tables from our 14 PCV-Research runs are specific to our charge types and model versions. Publishing them as general guidance would be misleading. | **Removed from generalized /pace.** |

### Design Principles That Drove Rejections

1. **No false confidence.** A tool that claims to do something but does it poorly is worse than no tool. (Applies to: /sanitize, /cite)
2. **No premature implementation.** If we have zero evidence it works, don't ship it. Test first, ship second. (Applies to: /study-breakdown, /integrity-check)
3. **No redundant commands.** If an existing command + a teaching guide covers the use case, don't add a wrapper. (Applies to: /grading-rubric, /research-audit)
4. **No maintenance multiplication.** Per-persona variants double the files to maintain. One command + config + guides is the right architecture. (Applies to: persona variants)
5. **No proprietary assets in public repos.** University branding, project-specific safety nets, and internal infrastructure don't ship. (Applies to: NC State theme, safety hooks, ECL-lite.) From v2.2.0 a safety net may ship as a mechanism with no project's list inside it: the list is the user's config, so the hook protects the user's paths and nobody else's.

---

## What Was Lost in Generalization

Each command was generalized from a project-specific version. Here's what was intentionally removed and why that's acceptable:

| Command | Removed Feature | Why Acceptable |
|---------|----------------|----------------|
| `/coa` | ECL-lite scorecard, PRECEDENT_INDEX, `coa/personas/` paths | Built-in roster fallback works out of the box. Session tracking is v2+. |
| `/pace` | JIT reference gate, per-task cost benchmarks, citation tier verification | Core 4-agent pattern is fully generic. Cost benchmarks were project-specific. |
| `/improve` | Read-only file list (project-specific protected files), `plans/` folder assumptions | Works on any project with a CLAUDE.md. First-time mode added for projects without one. |
| `/startup` | Multi-directory summary scanning, priority rules, MCP monitoring | Config-driven: reads `workstreams` and `summary_folder` from toolkit-config.md. |
| `/dailysummary` | Parameter-specific numerical verification, incident documentation | Generic numerical accuracy check preserved. Sonnet fallback added. |
| `/commit` | Project folder categorization (project-specific folder names) | Uses git diff to infer structure. No hardcoded folder names needed. |
| `/quarto` | NC State theme references | BYOT architecture. Theme is a user-provided SCSS file, not bundled. |
| `/readable` | Hardcoded `/tmp/` path | Cross-platform temp path via Python `tempfile`. |

---

## v2+ Roadmap

Items deferred from v1.0, ordered by estimated value:

### Deferred (not in v2.0; still waiting on classroom testing)

1. **Overlay commands** (`/pcv-class`, `/coa-class`, `/pace-grade`) — PCV structured for course assignments, CoA reframed as discussion prompts, PACE for rubric grading. Requires testing with actual students first.
2. **Session history tracking** — Optional PRECEDENT_INDEX for CoA sessions. Configurable via toolkit-config.md.
3. **Auto-detect workstreams** in `/startup` — Replace manual config with git/folder inference.
4. **ECL-lite scoring** — Council session quality metrics. Useful for longitudinal research.

### v3+ (speculative)

5. **Citation management** (`/cite`) — Only if we can do it well. BibTeX parsing + DOI resolution + PDF matching is a significant engineering effort.
6. **PII scanning** (`/sanitize`) — Only if we can integrate Presidio or equivalent, not a regex hack.
7. **Cross-model council** — CoA with Gemini/GPT members alongside Claude. Currently works via MCP but requires manual setup.
8. **DataFrame integration** — Instrumentation data in Julia/Python DataFrames for richer analysis.
9. **Chair-vs-panelist token-cost telemetry** — Instrument Chair-synthesis vs panelist token consumption per `/coa`, `/pace`, `/review`, `/pcv` run. Motivation: surface hub-spoke coordination overhead empirically. (Inspired by 2026 commentary on agent-coordination cost; deferred until reproducible measurement is in scope.) v0.1 ships without; CSV schema migration deferred to avoid breaking `runlog.csv` contracts. Open question: per-panelist breakdown granularity vs single Chair-vs-rest aggregate.
10. **Generalize `/meetingbreakdown` for toolkit** — Currently user-level only; toolkit counterpart deferred until generalization pattern stabilizes.

### Topology Selection

The toolkit's commands fall into two topological shapes; this table maps task shape to recommended command. This is documented as toolkit-internal best practice based on session experience.

| Task shape | Topology | Recommended command |
|---|---|---|
| Global-state code (refactors, lockfiles, sync edits) | Solo | direct edit, no agents |
| Brittle reasoning (parallelizable, unstable) | Market-shaped | `/coa --quick` |
| Decomposable, coherent synthesis needed | Hub-spoke | `/coa`, `/pace`, `/review`, `/pcv` |

External inspiration: hub-spoke vs market topology distinction echoes a recent advisor-shared analysis (n=15, no seeds — weakly supported); rows above are toolkit-internal best practice, not a citation of that result.

---

## Versioning Policy

- **v1.x** — Bug fixes, documentation improvements, config template updates. No new commands. *D-2 ruling (2026-05-02): "command" means a `.md` file under `shared/commands/` that gets installed to `~/.claude/commands/`. Audit/helper scripts under `scripts/` (e.g., `emit_run_report.sh`, `refresh-pcv-bundle.sh`) are not "commands" and may be added or revised within v1.x without violating the no-new-commands rule.*
- **v2.0** — Generalizes and hardens the commands v1.x already shipped. The one new command, `/setup`, exists to remove author-specific defaults, not to add a capability.
- **v2.0.x to v2.1** — Bug fixes and hardening; no new command. *(Until v2.2.0 this bullet read: "New commands are added one at a time, each approved individually and each passing the weekly-use test.")*
- **From v2.2.0** — Each minor release ships **one list** of new commands and skills, approved together before the release; how often the author used each item is evidence for its place on the list, not a gate on its own. For this policy a **command** is anything a user invokes by name: a file under `shared/commands/`, a skill under `shared/skills/`, or `/pcv`. Helper scripts under `scripts/`, seat agents under `coa/agents/` and hooks under `hooks/` are not commands. A change to a command's name or arguments is listed in the changelog of the release that makes it. Removing a command, or renaming one with nothing left at the old name, is a major version. A rename that leaves a pointer at the old name for one release (a command file that only names the new one) is a minor version; the next release removes the pointer, and both changelogs say so. *(Until v2.2.0 this read: "removing or renaming one is a major version." v2.2.0 renamed `/dailysummary`, `/weeklysummary` and `/runlog` this way.)*
- **PCV upstream** — PCV files are Dr. Kay's upstream. We distribute v3.14 as-is. Version bumps come from Dr. Kay's repo; maintainer-only via `scripts/refresh-pcv-bundle.sh --version <tag>`. Student/user-facing install never touches the network for PCV.

---

## Conventions for this document (added 2026-05-02 per /coa Q5 Z1 ruling)

Three identifiers, three jobs — used consistently throughout DESIGN.md and the rest of the toolkit:

- **Brand name** (prose): **Research Amp Toolkit**. Used in README hero copy, CITATION text, slide decks, anywhere a human reads.
- **Path / repo slug**: `Research-Toolkit/`. Used in install instructions, `git clone` URLs, and any doc telling a user where the toolkit lives on disk after a clone.
- **Legacy on-disk name**: `ai-research-toolkit/`. The pre-rename directory name. Appears only in v1.0–v1.3 changelog narrative for audit-trail purposes — NOT in user-facing instructions for v1.4+.

**Command count source-of-truth**: the standalone commands listed by the `SHARED_COMMANDS` and `STUDENT_ONLY` arrays in `install.sh` (15 at v2.0) + `/pcv` (registered via `~/.claude/skills/`) = **16 user-visible commands**. Any prose count in any doc must match this rule; the install banner derives counts from the arrays at runtime, and `tests/check_claims.py` fails the build when a page disagrees.

**Recipe CWD invariant**: All shell recipes in user-facing docs assume CWD = the toolkit clone root (`Research-Toolkit/`). No `cd ai-research-toolkit/...` chains. If a recipe requires a deeper directory, the recipe begins with one bare `cd <subdir>/` line; never with the toolkit name as a prefix.

---

## File Inventory

```
Research-Toolkit/                        (v2.0.0; pcv/ is the upstream bundle)
├── README.md                            Root documentation
├── LICENSE                              MIT
├── VERSION                              The release version; check_claims.py holds every page to it
├── CITATION.md                          BibTeX + attribution prose
├── CITATION.cff                         Machine-readable citation
├── CONTRIBUTING.md                      Contribution guidelines
├── EVIDENCE.md                          What each claim rests on (reproducible / measured / observed)
├── DESIGN.md                            This file
├── POSITIONING.md                       Who the toolkit is for and not for
├── QUICKSTART.md                        First-session walk-through
├── USAGE_GUIDE.md                       Full command reference
├── llms.txt                             Plain-text summary for language-model readers
├── toolkit-config.md                    User configuration template (/setup fills it in)
├── install.sh                           Dual-mode installer (array-driven counts)
├── .github/workflows/tests.yml          CI: gates, mutation checks, shell parse, real install (Linux + macOS)
├── instructor/
│   ├── README.md                        Instructor quick start (9 commands)
│   └── guides/                          Teaching guides: PCV in courses, CoA for discussion,
│                                        PACE for grading, /audit for student submissions
├── student/
│   ├── README.md                        Student quick start (16 commands)
│   └── bootstrap.md                     In-session installer for Claude Code (globs, never a typed list)
├── coa/                                 CoA roster, personas, optional cross-model setup
├── hooks/                               Optional hooks (install with --hooks): usage counter + its
│                                        self-test and mutation check, token budget, summary-folder guard
├── shared/commands/                     15 generalized commands
│   ├── setup.md                         Config interview (v2.0)
│   ├── coa.md                           Council of Agents
│   ├── pace.md                          Parallel Agent Consensus
│   ├── audit.md                         Citation & numerical audit (v1.0+)
│   ├── review.md                        Three-lens document review (v1.4)
│   ├── improve.md                       Infrastructure scanner
│   ├── simplify.md                      Code/document review
│   ├── help.md                          Triage entry-point (v1.3)
│   ├── runlog.md                        Longitudinal run observability (v1.1)
│   ├── startup.md                       Session briefing
│   ├── dailysummary.md                  Daily work summary
│   ├── weeklysummary.md                 Weekly aggregation
│   ├── commit.md                        Intelligent git commits
│   ├── quarto.md                        Slide generation
│   └── readable.md                      Document extraction
├── scripts/                             Shared helper scripts
│   ├── emit_run_report.py               Run instrumentation helper, installed to ~/.claude/toolkit/scripts/ (+ _selftest, _mutations)
│   ├── emit_run_report.sh               Launcher for the .py, kept for callers in a clone
│   ├── usage_counts.py                  Per-command usage report (+ usage_counts_mutations.py)
│   └── refresh-pcv-bundle.sh, check-pcv-upstream.sh, ...   Maintainer-only PCV upstream sync
├── tests/
│   ├── README.md                        Gate and fixture index
│   ├── check_toolkit.py                 Release gate: command contract, home paths, credentials, emails, private tokens
│   ├── check_claims.py                  Release gate: every count and version matches the tree
│   ├── check_install.py                 Release gate: real installs give every file the commands call (v2.0.2)
│   ├── check_*_mutations.py             Proof that each gate can fail
│   └── smoke/                           Hand-run fixtures
│       ├── audit_smoke.md, paper.md, sources/   /audit fixture
│       ├── audit_deep_smoke.md          /audit --deep fixture (v1.7)
│       ├── readable_gap_smoke.md        /readable gap-marker fixture (v1.7)
│       ├── pace_source_verification.md, sales_fixture.csv   /pace Step 2e fixture
│       ├── help_triage.md               /help triage fixture (v1.3)
│       ├── commit_grouping.md           /commit logical-grouping fixture
│       └── runlog_parser.md             /runlog parser fixture (v1.2 — synthetic, portable)
├── references/                          JIT recipe files: preventable_errors.md, iron_rules.md,
│                                        processing_student_submissions.md
└── pcv/                                 PCV v3.14 (Dr. Kay's upstream; refresh via scripts/refresh-pcv-bundle.sh)
    ├── skill/                           Recursive (handlers, hooks, planning, construction, verification, transition, bundled)
    └── agents/ (4 files)                pcv-builder, pcv-critic, pcv-research, pcv-verifier
```

---

## v1.1 Canonical `run_log.csv` Schema (2026-04-17)

All tools that emit instrumentation MUST append rows using this **13-column schema** (unified with historical /pace, /coa, /pcv-research rows):

```csv
run_id,tool,tool_version,date,task_summary,outcome,model,agent_count,convergence_rate,agree_count,diverge_count,report_path,notes
```

**Rules**:
- **Multi-agent commands** (/pace, /coa, /pcv-research): fill `agent_count`, `convergence_rate`, `agree_count`, `diverge_count` with numeric values.
- **Single-agent commands** (/audit, /improve, /dailysummary, /commit, /startup, /runlog): leave those 4 columns **EMPTY** (not 0, not N/A — empty). They have no convergence semantics.
- **All commands**: write a JSON object in the `notes` cell holding structured fields (CSV-quoted, with `""` escaping internal quotes). Keys are command-specific; downstream consumers parse as JSON.
- **Parsing**: downstream consumers (e.g., /runlog) MUST use Python's `csv` module (or equivalent CSV-aware parser), **not** raw `awk -F','`. The `task_summary` and `notes` cells contain embedded commas which break naive splitting.

**Historical compatibility**:
- Legacy rows (pre-2026-04-10) may have older 9-column schema or column-shifted tool-name-in-position-1 errors. The run-report helper (`scripts/emit_run_report.py` since v2.0.2; `emit_run_report.sh` before) auto-creates the canonical 13-column header if the file doesn't exist; it appends to existing files regardless of header shape.
- `/runlog`'s parser heuristically detects legacy/malformed rows (tool column starting with `2026-`, `2025-`, `pace_`, `coa_`, `pcv_` is treated as a column-shifted legacy row) and skips them with a count in the evidence footer.

**Why this was decided**: Pre-v1.1 /pace, /coa, and /pcv-research each wrote their own ad-hoc instrumentation. During v1.1 planning (2026-04-17), `emit_run_report.sh` was built with a 9-column schema that collided with the 13-column historical schema. Reconciled in-session to the 13-column canonical. Recorded here so v1.2+ contributors don't reproduce the mismatch.

---

## v1.1 Changelog (2026-04-17)

Added:
- `/runlog` command — longitudinal run observability (198 lines)
- `scripts/emit_run_report.sh` — shared instrumentation helper (~130 lines)
- `tests/smoke/` — fixtures for /audit, /pace, /runlog
- `references/processing_student_submissions.md` — JIT recipe
- `instructor/guides/using-audit-for-student-submissions.md` — new (170 lines)

Changed:
- `/coa` STEP 1b — added local-Sonnet fallback when Gemini cross-check fails (was silent skip)
- `/dailysummary` — added `--append-pointer` mode, Step 0c filename collision resolution, Step 1 WSL-aware 5s git timeouts, evidence footer, instrumentation call
- `/startup` — evidence footer + instrumentation call
- `/audit` — instrumentation call + smoke-test pointer
- `/improve` — Priority-3 gating (skip historical reads when <3 friction signals) + gate self-test log + instrumentation call
- `/commit` — instrumentation call
- `/pace` — cross-linked /audit integration for grading workflow
- `instructor/guides/using-pace-for-grading.md` — expanded with /audit integration
- README.md — 3-problem student-facing rewrite + fork-friendly disclaimer + /runlog + 13-command count
- `jbenhart44.github.io/index.html` — parallel updates

Deferred to v1.2:
- Instrumentation for /weeklysummary, /quarto, /readable, /simplify (no usage evidence)
- `/audit` + `/audit-library` merger
- `/dailysummary` + `/weeklysummary` merger

---

## v1.2 Changelog (2026-04-18)

**Renamed: `AI-Assisted Research Toolkit` → `Research Amp Toolkit`**

Rationale: The prior name read as "toolkit doing AI research" rather than "toolkit for doing research with AI" (design review with Dr. Kay, 2026-04-15). Two-round naming process. Round 1 winner (`socratic-research-toolkit`, 18/20 score) was rejected by Jake on tone — too academic-jargon-heavy. Round 2 surfaced human-dependence-framed candidates; `research-amp` won the deployment-criteria comparison (113/125, narrowly behind `thinking-tools-research` at 114/125 on K2 methodological-anchor only). After the Round 2 lock, Jake appended "Toolkit" (4/19) to restore the collection-of-commands signal and improve student-fit readability — final name: **Research Amp Toolkit**.

Why "Research Amp" as the metaphor core: the amplifier framing is literal — the tool produces zero output without the user's signal. This honors Dr. Kay's "user thinks / tool guides" criterion from the same review and avoids both SaaS-marketing fluff (he rejected "companion" and "copilot" names) and agent-overloaded vocabulary. Single-syllable hook ("amp") for outreach memorability.

Why append "Toolkit": (a) restores the collection-of-things signal that a 13-command repo needs, (b) improves student-fit — "the Research Amp Toolkit" reads more natural than bare "Research Amp" in a Kay-to-student email, (c) keeps URL reasonable at 49 chars for `research-amp-toolkit`, still shorter than the pre-rename `ai-research-toolkit`.

Changed:
- README.md — hero sentence rewritten around amplifier framing; `/audit` smoke fixture path updated
- DESIGN.md — title + this changelog
- CITATION.md — attribution paragraph + BibTeX `title` field updated
- toolkit-config.md — template default updated (if applicable)
- jbenhart44.github.io — tag cloud, workflow table, hero sentence
- Directory references inside docs: `ai-research-toolkit/` → `research-amp/` (mechanical replace across 13 files)

Not changed (deferred):
- Directory rename on disk — pending coordinated commit
- GitHub repo URL — separate operation, may keep `Research-Toolkit` as the public repo slug for inbound link continuity

Earlier shortlist (Round 1, superseded): socratic-research-toolkit / claude-research-assistant / research-scaffold / guided-research-toolkit. Round 2 was scored against six naming criteria (K1-K6) reviewed with Dr. Kay.

---

## v1.3 Changelog (2026-04-19)

**Added: `/help` — Socratic triage command (EXPERIMENTAL)**

Motivation: design review feedback (2026-04-15) flagged the paradox-of-choice problem as the 13-command toolkit grows. A stressed student on a Pro plan at 11pm shouldn't have to read the README to find the right command. `/help` takes a one-line situation and recommends 1-3 commands after 0-1 clarifying questions.

Design process: The v0.1 draft was reviewed by a 3-seat CoA Quick Panel (Skeptic + Practitioner + Cognitive Ergonomist) on 2026-04-19. All three converged on "NOT ship-ready, but minor revision not redesign" via three independent causal chains:
- Skeptic: structural defects (inventory drift, leaked Jake-specific paths)
- Practitioner: factual errors vs filesystem (spec claimed 13 commands / 10 fixtures; disk has 12 / 4) + silent `emit_run_report.sh` parser bug
- Cognitive Ergonomist: Examples 2 & 3 exceeded Miller-under-stress working-memory ceiling by 2-3x; 23% alarm-fatigue rate on fixture pointers

v0.2 applied all 6 tactical fixes (T1-T6), 2 strategic contracts (S1 inventory sync, S2 success metric), and the I3 shell test for field encoding. Gemini cross-check truncated at ~400 chars; local Sonnet fallback invoked per /coa v2.1 protocol. Sonnet surfaced one independent insight: the modal stressed-student input is not "I have a paper and I'm worried about citations" but `/help I'm stuck` or bare `/help` — treated as modal case, not edge case, via the shape-C scaffold menu.

**Shipped WITHOUT the 5-student premise pilot the council recommended (I1 deferred).** Rationale: pilots are logistically hard pre-rollout, and the success metrics + re-open triggers give us a 3-4 week feedback loop in live classroom use. Premise resolution happens via `run_log.csv` signals, not pre-registration.

Success metrics (pre-registered): `/help` is useful if AT LEAST ONE of — (1) ≥20% of recommended commands are subsequently run within 30 min, (2) sessions using `/help` have higher command-diversity than sessions without, (3) low rate of same-student multi-invocation for the same problem. If NONE fire by end of fall 2026, `/help` is a removal candidate.

Re-open triggers: R1 (inventory drift >10%), R2 (clarify-then-no-match correlation), R3 (study-aid inversion pattern).

Added:
- `shared/commands/help.md` — the command file (~180 lines, follows audit.md pattern)
- `tests/smoke/help_triage.md` — 4 test cases (shape A, shape A-with-prereq, shape C scaffold, no-match)
- README.md — new "Triage Layer" section
- DESIGN.md — this changelog + Tier 4 row in command inventory
- jbenhart44.github.io — /help added to command list + tag cloud (pending)

Design artifacts (the v0.2 spec and the council session) are kept in the maintainer's planning notes and are not bundled with the toolkit.

---

## v1.4 Changelog (2026-04-19)

**Two coordinated changes: PCV v3.14 bundle bump + `/review` command ship.**

### PCV v3.14 bundle bump (was v3.9)

Dr. Kay released PCV v3.14 on 2026-04-19. Per his email: "significantly more efficient, running approximately 3 times faster and using about half the number of tokens as previous versions." This is a 5-version jump; intermediate v3.10-v3.13 included the breaking `plans/` → `pcvplans/` rename in v3.13 and the new `handlers/` + `hooks/` shell-script architecture in v3.14.

v3.14 upstream claim of 3× speed / 50% token reduction is **upstream pending local remeasurement** — we have not independently benchmarked it in this toolkit. See `EVIDENCE.md`.

Migration plan: 8 open questions and a 10-phase plan, produced with `/pcv-research` on 2026-04-19 (kept in the maintainer's planning notes).

Bundle changes:
- `pcv/` updated from Kay's upstream (shallow clone from `github.com/mgkay/mgkay.github.io/main/pcv/`, SHA pinned via `.upstream-sha`)
- New `scripts/refresh-pcv-bundle.sh` — maintainer-only refresh from upstream, requires explicit `--version` arg
- New `scripts/check-pcv-upstream.sh` — drift detector (single HEAD request, exits 1 on drift); CLAUDE.md audit-flag entry added
- New `scripts/rollback-pcv-v314.sh` — scripted rollback from tarball; dry-run gate before execute

Install.sh changes:
- Flat-file PCV install loop replaced with recursive `cp -r` (v3.14's subdirectory structure — handlers/, hooks/, planning/, construction/, verification/, transition/ — was incompatible with the v3.9 flat-file assumption)
- Added `chmod +x` for handler + hook shell scripts (OneDrive WSL strips exec bits; install.sh now restores them automatically)
- Added `/review` + `/runlog` (previously unregistered) to SHARED_COMMANDS and STUDENT_ONLY respectively
- Command count bumped: 12 → 15 full, 6 → 8 minimal

**HOME-isolated smoke test (Phase 3 of migration plan)** caught the flat-file install bug before touching Jake's real `~/.claude/`. This validated Instance 2's bundle-first + dogfooded install order over Instance 1's local-first order in the PCV-Research synthesis.

### /review — three-lens document review (SHIPPED v1.0)

Takes an external document (paper, advisor memo, spec draft) and runs it through three parallel expert lenses — Skeptic + Practitioner + Editor — producing 5-10 takeaways + project relevance + 3 implications per lens, plus a Chair synthesis. Complements /coa (decisions) and /pace (deliverables) as the third-flavor multi-agent primitive: /review is for **absorbing** external writing.

Design: The three lenses are the mandatory Skeptic + Practitioner from the /coa ROSTER plus Editor (the ROSTER's designated Historian-replacement for prose documents). Chair role is inline synthesis by the Clerk — no 4th agent, reducing token cost vs /coa Quick Panel while preserving multi-perspective coverage.

Design process: Lean adversarial self-review on the spec caught two issues before smoke (project-context extraction not specified; PDF/docx guard missing from Step 0); both patched. Smoke test was the command's first substantive invocation — running /review against a design memo on text-based formats for Claude Code. Results: three agents ~30s each in parallel, ~106K tokens total (within 80-120K projected envelope), non-overlapping outputs, Chair synthesis produced cleanly, shipped as v1.0 with no post-smoke revisions.

**Smoke-test artifact**: the review output of that run (kept privately, not bundled) validated the command's value proposition on a real document; `EVIDENCE.md` records it as the v1.0 baseline.

**Future work tracked**: /review as a template for per-command documentation on the public toolkit website.

Added:
- `shared/commands/review.md` — the command file (~240 lines)
- Install.sh registration + command count bump (see above)
- `EVIDENCE.md` — new /review section with smoke-test metrics
- `evidence/command_performance_log.md` — debut invocation logged (author-local instrumentation; not bundled with the toolkit)

Bonus bug caught during I3 shell test: the spec's user field `outcome=match` collided with the script's native `outcome:` YAML key, producing duplicate keys. Renamed to `triage_result=match`. This is a lesson for future command specs — do not use field names that shadow the script's built-ins.

---

## v1.5 Changelog (2026-05-11)

**Three coordinated prompt edits to `/audit`, `/quarto`, `/commit` after a multi-stage /pcv-research + /coa validation pass.**

This is the first toolkit-wide enhancement wave driven by structured comparative review rather than direct user-encountered incident. Prior changelogs (v1.1–v1.4) were motivated by failures encountered during live use (commit-attribution bug, citation pipeline misses, PCV bundle drift). The v1.5 wave was produced by:

1. `/pcv-research` BF-1 + BF-2 run on 2026-05-11 → 10-item enhancement queue
2. `/coa` Working Council session on 2026-05-11 → 4-seat (Skeptic + Practitioner + End User + Editor) + Gemini cross-check → conditional partial proceed
3. v1.5 ships items 1, 2, 5 of the queue (Tier 1, three prompt-only edits). Items 3, 4 (Attack Intensity Preservation + /coa Concession Threshold) deferred 48h pending advisor surface decision per End User finding. Item 7 (/simplify prose-branch watchlist) deferred indefinitely pending domain-vocabulary allowlist per Editor finding (operations-research methodology vocabulary would produce false-positive AI-tell flags under the proposed checklist).

Source artifacts for this wave are tracked in the maintainer's internal planning surface; this changelog records the user-facing changes only.

### Change 1: `/audit` MATERIAL GAP refusal token (Item 1 of the queue)

`shared/commands/audit.md` "Important Rules" section gains a sixth rule documenting the `[MATERIAL GAP: <claim> — no grep hit for "<pattern>" in <searched dirs>]` token. The token replaces the pre-v1.5 informal `% TODO: citation needed` convention with a structured form that is machine-greppable.

**Sentinel-comment guard (binding constraint from /coa Editor seat)**: the marker emits to the audit report directly, but when /audit is also recommending an inline edit to the document being audited, the marker MUST render as a comment sentinel for that document's format (`% [...]` for LaTeX, `<!-- [...] -->` for Quarto/HTML/Markdown), NEVER as visible body text. Rationale (Editor's pre-mortem): a visible `[MATERIAL GAP: ...]` line in submitted prose is louder than the underlying gap — a reviewer reading it instantly knows the author used an LLM and didn't clean up before submission. The quiet placeholder convention defends author credibility; the loud version damages it.

### Change 2: `/quarto` MATERIAL GAP speaker-note-only guard (Item 2 of the queue)

`shared/commands/quarto.md` Step 3c "Data Accuracy" section gains a fifth rule extending Change 1 to slide bullets. When `/audit` returns NOT FOUND or MISMATCH for a value that would otherwise appear on a slide, the `[MATERIAL GAP: ...]` marker goes ONLY in the speaker-note block (`::: {.notes}` ... `:::`), NEVER as a slide-face bullet.

**Why stricter than Change 1**: slide bullets are seen by audiences (conference attendees, committee members, site-visit panels), not just authors. A projected `[MATERIAL GAP: ...]` line at a committee meeting is a credibility hit that the comment-sentinel guard for prose drafts does not need to address. Speaker notes are author-only by default in the Quarto render pipeline.

### Change 3: `/commit` workstream-scope pre-check (Item 5 of the queue — IRON RULE re-injection)

`shared/commands/commit.md` gains a new Step 0a (after Step 0 "Survey All Changes", before Step 0b "Slow-Filesystem Detection") that mechanically enforces the project-level CLAUDE.md terminal-scope rule at the commit boundary.

Mechanism: after `git status --short`, count distinct top-level workstream directories across modified + untracked files. If ≥2 workstreams are touched, re-inject the terminal-scope hard rule into the user-facing output and require explicit confirmation (`scope-confirmed: <ws>` to stage only one workstream, or `multi-scope-acknowledged` for deliberate cross-scope commits). If only 1 workstream is touched, skip silently. This converts a previously discipline-only rule into a mechanically enforced check at the highest-leverage boundary, where cross-scope leak silently propagates to git history.

### Items deferred from this wave (and why)

- **Items 3 + 4 (Attack Intensity Preservation + /coa Concession Threshold + Frame-Lock Detection)**: deferred 48h. Three Council seats converged on item 3 as the highest-risk item: Skeptic flagged that the same model self-assesses its own 1–5 evidence rubric (self-certification circularity); End User flagged that the "≥4" threshold is a free parameter with no documented calibration rationale, violating the "transparency is structural rather than procedural" tenet; Practitioner flagged that items 3 and 4 both modify `coa.md` and must ship as a single coordinated PR. Resolution requires an advisor surface decision on whether /pace and /coa behavioral changes ship with prior notification or post-hoc changelog.
- **Item 7 (/simplify prose-branch style-tells)**: deferred indefinitely. Editor seat showed the proposed style-tell watchlist is calibrated for general writing — flagging terms like "robust" as AI-tells when they are standard operations-research methodology vocabulary ("robust optimization", "robust regression"). Pursuing this requires a domain-vocabulary allowlist + report-only mode (no auto-edits) before adoption is safe.
- **Items 6, 8, 9, 10 (Tier 2)**: deferred to the week of 2026-05-19, post-submission. Item 9 (passport.yaml triple for cross-command state) was further gated on a prior-work `grep` of `startup.md` — which returned zero hits, confirming the item needs full implementation from scratch.
- **Tier 3 / v2.0 deferrals**: live-network paper existence checks (default-path H2 violation); two-call generator-evaluator gate structure (not verified against current `/coa` and `/pace` orchestrators); plugin-marketplace install architecture (changes install surface, deferred past v1.x stability promise); cross-model benchmark utility (deferred until post-grant-submission).

### Hard rules honored

- **No /pcv or /pcv-research changes** in this wave. PCV is Dr. Kay's upstream project, so /pcv changes go through him. Items 3 + 4 touch `coa.md`, not `/pcv` — but the End User finding raised an analogous "co-author surface" concern about /pace behavioral changes that the user (Jake) will address with Dr. Kay before items 3 + 4 ship.
- **Same-model caveat preserved**: the queue was generated by Sonnet 4.6 BF instances, synthesized by Sonnet 4.6 Chair, and implemented by Sonnet 4.6 in this commit. The /coa Gemini cross-check returned a strong divergent signal (paraphrased: wait, and postpone all enhancements until the author's next paper is submitted), which the Chair downgraded as paternalistic on the urgency framing but preserved as the top Surprise Finding (S1: mono-model audit chain) — addressed in this commit by limiting the wave to items 1, 2, 5 (the three highest-confidence, lowest-coordination-risk items) and deferring everything else pending additional verification gates.
- **Honorifics**: "Dr." used consistently for faculty throughout the changelog and v1.5 sources.
- **No Claude-Code coauthor**: this commit follows the toolkit's standing no-attribution rule.

### What did NOT change

- No new commands. No new files in `shared/commands/`. No new dependencies. No new install.sh registration. No version bump in `pcv/skill/VERSION` (Dr. Kay's project, untouched). The three edits are additive prompt rules within existing command files; the toolkit's command count and install surface are unchanged.

### Cross-model verification gate — gate fired, found a real fix

Before commit, the actual edited prompts for Changes 1 and 2 were handed to a cross-model query (via `mcp__crossmodel__query_model`) with a synthetic scenario: a value attributed to a fabricated paper. The cross-model verifier was asked to predict the behavior of the edited prompt and flag any failure mode.

- **Change 1 (/audit)**: cross-model verifier predicted correct behavior. Shipped as drafted.
- **Change 2 (/quarto)**: cross-model verifier flagged a real failure mode the original drafting missed — the rule said "the marker goes ONLY in the speaker-note block," but did not handle slides that have no `::: {.notes}` block yet. The implementing model could silently omit the marker when the speaker-note section was absent, losing the gap-tracking artifact entirely. Fix applied pre-commit: an explicit "if the slide does not already have a `::: {.notes}` block, create one" clause.

This is the first instance of cross-model verification catching an underspecification on a Tier-1 toolkit edit before merge. Worth codifying as a v2.0 standing policy: any prompt edit to a citation-pipeline command is handed to an independent model for behavior prediction on a synthetic-failure scenario before the edit is committed.

---

## v1.6 Changelog (2026-05-11) — Documentation pass

**Five additive documentation artifacts: `POSITIONING.md`, `references/preventable_errors.md`, `references/iron_rules.md`, README headline philosophy, `llms.txt`. No command-prompt changes; no behavioral changes; no install-surface changes.**

The v1.5 wave added rules to commands; v1.6 makes the toolkit's positioning, error surface, and rule index discoverable in their own right. The motivation is that a user evaluating whether to install the toolkit, a contributor proposing a change, or a future maintainer auditing a load-bearing rule should not have to read the entire command corpus to find the answer to "who is this for?", "what does it prevent?", or "where is rule X enforced?". Each of these questions now has a single navigable file.

### Change 1: `POSITIONING.md` — what this toolkit is for, and what it is not

A dedicated positioning artifact, separate from `README.md` (install + catalog) and `DESIGN.md` (architecture + changelog). States the toolkit's target users (PhD students, early-career researchers, faculty advisors, instructors) and the categories of work it is deliberately not optimized for (general-purpose software engineering, persistent-memory agents, hidden AI use, production CI/CD, black-box installation). Articulates six design commitments — citation pipeline as primary gate; planning/construction/verification as three auditable steps; multi-perspective adversarial review as first-class; text-first architecture; per-user forkability; honorific and authorship discipline — and four intentional non-goals so the omissions are not mistaken for oversights. This file is the answer to "should I install this?" and "who is this for?"

### Change 2: `references/preventable_errors.md` — twelve error classes and what prevents each

A catalog of the categories of academic-research error this toolkit's rules and commands are designed to prevent in deliverables. Twelve classes (E1 through E12): misquoted figures attributed to real sources, fabricated citations, premature filling of unknown values, silent methodology changes, plausible-sounding filler, frame-lock under user pushback, single-context simulation of multi-agent review, slide-face leakage of author-only markers, cross-workstream commit bleed, honorific drift in reader-facing artifacts, co-author attribution to AI assistance, and submission-time discovery of an open gate. Each entry pairs the error pattern with the command or rule that prevents it. This file is the answer to "what is the toolkit's friction buying me?" and to "would this simplification weaken a load-bearing guardrail?"

### Change 3: `references/iron_rules.md` — consolidated rule index

The toolkit's iron rules live in the command files that enforce them. That distribution is correct for invocation-time enforcement, but it makes it hard to scan the constraint surface in one place. This file is the navigation surface: every iron rule, the file it lives in, and a one-line summary of which preventable-errors entry motivates it. Rules are grouped by domain — citation and verification, deliverable integrity, multi-agent discipline, authorship and attribution, workstream and commit hygiene, methodology and reproducibility, read-only constraints. This file is the answer to "where does rule X live?" and "what rules does my proposed change need to respect?"

### Change 4: README headline philosophy

The README opener gains a single-line philosophical framing — "Every empirical value cites a file on disk. Every claim survives `grep`. Dissertation-grade, not vibe-grade." — placed above the v0.1 status warning. The line is meant to be the first thing a reader encounters and to set expectations about what kind of tool this is before they reach feature lists. The README also gains pointers to `POSITIONING.md`, `references/preventable_errors.md`, and `references/iron_rules.md` in the existing "Design rationale" links line.

### Change 5: `llms.txt` — LLM-consumable summary at repo root

A short, single-file summary at the repository root in the conventional `llms.txt` discoverability format. States the toolkit's purpose, target users, command catalog organized by workflow phase, key documents, design commitments, and install instructions. Intended for consumption by language-model agents orienting to the repository — downstream installers, contribution helpers, indexing agents — that benefit from a concise self-contained summary rather than having to read multiple documents to understand what the toolkit is and is not.

### What did NOT change

- No new commands. No new files in `shared/commands/`. No new dependencies. No new install.sh registration. No version bump in `pcv/skill/VERSION` (out of toolkit scope). The five additions are pure documentation; the toolkit's command count, install surface, and runtime behavior are unchanged.
- No command-prompt edits and no rule changes. v1.6 documents the existing rule surface; the rules themselves are as v1.5 left them.

### Disclosure of source pattern

The v1.6 wave is informed by reviewing the documentation layouts of several other Claude Code toolkits in adjacent problem categories (general-purpose software engineering, persistent-agent memory). The patterns adopted — a separate positioning file, a named error-class reference, a consolidated rule index, a one-line README framing, an `llms.txt` summary — are overarching documentation patterns observed widely across well-maintained toolkit repositories. The content of every file shipped in v1.6 is written from this toolkit's own provenance, its own rule structure, and its own design commitments. No external taxonomies, no external citations, and no external toolkit structures are reproduced.

### Hard rules honored

- **Honorifics**: "Dr. Surname" used throughout where doctorate-holders are named.
- **No AI co-author**: the v1.6 commit follows the standing no-attribution rule.
- **Citation pipeline**: no empirical values attributed to external sources are introduced in v1.6 artifacts — the new files describe the toolkit's own commitments and rule surface, with no numerical claims.
- **Workstream scope**: the v1.6 commit stages files exclusively from the `ai-research-toolkit/` workstream; the parent-repo submodule pointer bump is a separate commit in the parent repo.

---

## v1.7 Changelog (2026-05-12) — End-to-end citation pipeline

**Two coordinated edits that close the upstream-to-downstream loop on the citation gate: `/readable` now emits typed extraction-gap markers when a page cannot be read; `/audit` now recognizes those markers and additionally exposes a `--deep` sub-mode that extends the single-step grep gate to a five-step claim chain with a mandatory terminal verdict per citation.**

The motivation. v1.6 documented the citation pipeline as the toolkit's primary gate. Two failure modes in that pipeline survived the prior wave: (a) `/readable` could silently skip a page when extraction failed (image-only PDFs with OCR-resistant content, encoding errors, table renders the visual subagent could not disambiguate), leaving the downstream `/audit` unable to distinguish "the cited value is genuinely not in the paper" from "we never managed to read the cited page;" and (b) `/audit` ran a single-step grep gate that caught misquoted *numbers* but did not catch misquoted *methodology* — a value that appears in a paper's robustness section presented as a headline finding, or a value cited from a paper whose methodology has since been retracted or corrected. v1.7 addresses both.

### Change 1: `/readable` — typed extraction-gap markers

When pypdf returns empty for a page AND the fitz fallback returns empty AND the image-render visual-subagent path also fails to produce readable text, the `.txt` MUST contain an explicit typed gap marker at the corresponding `=== PAGE N ===` boundary, of the form `[MATERIAL GAP: extraction failure on page N — <reason>]`. The reason is mandatory and human-readable. The marker is the page content for that page — no best-guess approximation is written alongside it.

The marker is greppable: a downstream consumer can distinguish a clean empty page from an extraction failure with a single grep. Most importantly, it composes with `/audit`'s grep gate — see Change 2.

This is the upstream half of E5 (plausible filler) prevention. The toolkit's prior `/readable` design assumed an extraction failure was a transient problem the user would notice; the rest of the pipeline did not have a structural way to know an extraction had failed silently. The marker closes that hole.

### Change 2: `/audit` — GAP-IN-SOURCE recognition + `--deep` claim-chain sub-mode

Two additions to `/audit`, both additive.

**Addition 2a: GAP-IN-SOURCE status.** When the standard grep gate returns zero matches for a cited value, `/audit` now grep-checks the source `.txt` for a typed `[MATERIAL GAP: extraction failure on page <P>]` marker at the cited page before emitting NOT FOUND. If the marker is present, the status is GAP-IN-SOURCE — a different actionable finding than NOT FOUND. NOT FOUND tells the author "the cited value is not in the paper, fix the citation"; GAP-IN-SOURCE tells the author "we could not read the cited page, re-extract or inspect manually." Conflating the two produced wrong author behavior in the prior gate.

**Addition 2b: `--deep` sub-mode (claim-chain audit).** Invoked via `/audit <file> --deep`. Extends the single-step grep gate to a five-step chain. For every citation that passed the standard grep gate, the deep mode additionally checks: methodology section locatable in the source `.txt`; absence of any retraction or correction notice in the source paper or in a co-located retraction-notes file; and whether the cited value's location falls inside a robustness, supplementary, sensitivity, or appendix section while the document cites it as a headline result. The deep mode emits a structured YAML verdict per citation, one of five mandatory terminal states: `verified`, `partial`, `unverifiable`, `misattributed`, `retracted`. The verdict field is mandatory — the deep audit cannot terminate in ambiguity. An entry without a verdict is a defect.

The deep mode does not call external services. Retraction signals come from local `.txt` extractions and from user-curated co-located retraction-notes files (`<paper-stem>.retraction.md` or directory-level `RETRACTION_NOTES.md`). Live-network retraction lookup (CrossRef, Retraction Watch, Semantic Scholar) is explicitly out of scope for v1.7 — it would violate the no-live-network default-path constraint and is not addable as an opt-in flag within v1.7's scope.

The deep mode is a pre-submission gate, not an every-session step. The standard `/audit` remains the daily-use command. The deep mode adds the chain on top of the standard audit; a document submitted without the standard audit having passed is not made safer by skipping straight to deep mode.

### What did NOT change

- No new commands. The two changes are additive prompt edits within existing command files (`readable.md`, `audit.md`) and additive content within existing reference files (`preventable_errors.md`, `iron_rules.md`). The toolkit's command count, install surface, and runtime behavior outside the augmented modes are unchanged.
- No new dependencies. The deep mode uses Read + Grep tools the standard audit already has access to. No additional Python packages required.
- No changes to `/audit`'s default-mode behavior. Documents that the standard audit previously marked VERIFIED, MISMATCH, NOT FOUND continue to receive those statuses in the default mode. GAP-IN-SOURCE replaces NOT FOUND only when a typed extraction-gap marker is present at the cited page — a state that did not previously exist in `.txt` outputs.
- No changes to `/pcv` or `/pcv-research`. Out of scope per the standing rule that those commands are Dr. Kay's project.

### Verification gate that gated this change

A V1 mechanism-test gate was applied to the deep-mode design before any prompt edit was drafted. The three checks:

1. **No live-network on the default path.** The deep mode uses only local PDFs, local `.txt` extractions, and local co-located retraction-notes files. No HTTP requests, no SDK calls, no opt-in network flag introduced. ✓
2. **No DB or daemon dependency.** All chain steps are file reads; the YAML verdict is written to disk; no background process, no shared store. ✓
3. **Maps to a named error class in `preventable_errors.md`.** Refines E1 (misquoted figures) by extending the gate from value-level to methodology-level. The E1 entry now carries an explicit extension paragraph documenting the v1.7 refinement. ✓

The gate passed. Documented here so the precedent is visible: any future toolkit edit that proposes augmenting an existing command with a behavior whose mechanism resembles an external pattern must pass this three-check gate before the prompt is drafted, and the gate result is recorded in the changelog.

### Smoke fixtures

Two smoke fixtures ship with v1.7 — both stubs that document the test, since neither can be executed inside the prompt-edit harness:

- `tests/smoke/audit_deep_smoke.md` — fixture exercising the five-step chain on three citations: one clean (expected `verified`), one whose source `.txt` contains a retraction marker (expected `retracted`), one whose cited value falls inside a Robustness section but is cited as a headline result (expected `misattributed`).
- `tests/smoke/readable_gap_smoke.md` — fixture exercising the typed gap marker emission when a page cannot be extracted (image-only PDF page with OCR-resistant content). Documents the expected marker shape and the downstream `/audit` GAP-IN-SOURCE recognition.

Both fixtures should be run as part of the next test pass when a Python environment with the `/readable` dependencies is available.

### Hard rules honored

- **Honorifics**: "Dr. Surname" used throughout where doctorate-holders are named.
- **No AI co-author**: the v1.7 commit follows the standing no-attribution rule.
- **Citation pipeline**: no empirical values attributed to external sources are introduced in v1.7 artifacts — the changes describe the toolkit's own pipeline extensions, with no numerical claims requiring grep verification.
- **Workstream scope**: the v1.7 commit stages files exclusively from the `ai-research-toolkit/` workstream; the parent-repo submodule pointer bump is a separate commit in the parent repo.
- **Describe in own terms**: the v1.7 changes are framed as extensions of the toolkit's existing citation-pipeline commitment from v1.6; no external toolkits, papers, or feature names appear in the prompt edits, reference files, or this changelog.

---

## v2.0 Changelog (2026-10-19) — Generalized, and checked by its own gates

**v2.0 brings the shipped commands up to the author's current versions, removes everything that only made sense for one author, and makes the toolkit's own claims checkable.** The rule for the release: the commands v1.x already published are updated and generalized; anything new is approved one at a time. The only new command is `/setup`.

### Generalization: the tools ask instead of assuming

Where a command used to carry the author's folders, workstreams, course names or habits, it now reads them from `~/.claude/toolkit-config.md`, and `/setup` writes that file by asking. Optional keys (`startup_exclude`, `backlog_file`, `scheduled_jobs`, `extra_repos`, `commit_mode`, `shared_code_dirs`, `author_affiliation`, `quarto_theme_dir`, `slides_folder`) are asked by the command that needs them, the first time it needs them. Research examples stay where they explain a command; they are examples, not defaults.

### Refreshed commands

Nine commands were rebuilt from the author's current working versions and generalized: `/coa`, `/pace`, `/improve`, `/quarto`, `/startup`, `/dailysummary`, `/weeklysummary`, `/commit`, `/simplify`. `/help` gained `/setup`, `/review` and a pointer to the separate captioner tool.

### The toolkit checks itself

| Added | What it refuses | Proof it can fail |
|---|---|---|
| `tests/check_toolkit.py` (replaces `tests/smoke/fresh_clone_test.sh`) | a command without its contract, an absolute home path, a credential, an email outside the allowlist, a term from the user's private-token file | `tests/check_toolkit_mutations.py` |
| `tests/check_claims.py` | a count or version on any page that disagrees with `install.sh` and `VERSION`; it walks the tree, so a new page is checked the day it is added | `tests/check_claims_mutations.py` |
| `.github/workflows/tests.yml` | a push where any gate, self-test or mutation check is red, a shell script that does not parse, or an install that does not land (Linux and macOS) | the steps above |

The claims gate earned its place before release. Pages in the tree said 8, 12, 13 and 15 commands, and the landing page said 14. The first version of the gate missed five of them. Four sat in the instructor and student READMEs and the in-session installer, which it did not read because they were not on its hand-typed list; the fifth was written "12-command", a form it did not match. The list was replaced by discovery, the hyphenated form was added, and a mutation proves each fix would be caught if it were undone.

### Usage counter

`hooks/usage_counter.py` (opt-in with `install.sh --hooks`) records one row per command use; `scripts/usage_counts.py` reports the counts with a balance line. EVIDENCE.md's measured tier comes from this report over the author's own logs.

### Fixes

- `student/bootstrap.md` copied from a typed file list. The list had no `setup.md`, and it named 6 of the PCV skill's 41 files, so `/pcv` installed this way failed at its first handler call. It now globs each folder and verifies against the glob.
- `hooks/token_budget_guard.sh` declared an unused `declare -A` table, which prints an error on macOS's system bash 3.2. Removed; CI runs the hook under the system bash.
- USAGE_GUIDE.md linked every command to a page that returned 404. The links now point at the live command pages.
- EVIDENCE.md is rewritten in three tiers (reproducible, measured, observed). Claims with nothing behind them were removed.

### Removed

- `docs/` (31 files). The landing page lives in the site repository, which is its only copy now.
- `tests/smoke/fresh_clone_test.sh`, replaced by `tests/check_toolkit.py`. Every check it made is covered: the command contract and frontmatter window directly, the home paths by pattern, and its hand-picked project-term list by the private-token file, which every user now writes for their own terms instead of the gate carrying the author's. The old script, run against the v2.0 tree, passes.
- `hooks/command_evidence.sh`, an empty file since it was added. The usage counter and `scripts/emit_run_report.sh` do what its name promised.

### Attribution

The toolkit is by Jake Benhart. `/pcv` is Dr. Michael G. Kay's work, bundled unmodified at v3.14 and credited in LICENSE, CITATION.cff (`references:`), CITATION.md and the README.

### What did NOT change

- The PCV bundle (`pcv/`) is unchanged in this release.
- No command was renamed and no argument was removed. Checked by comparing every `--flag` and every usage line in each changed command file against the previous release, and by reading the argument handling of the commands that take free text.

---

## v2.0.1 Changelog (2026-10-19) — Fixes from the v2.0 review

Bug fixes only; no command, argument or behaviour of a command changed. Each fix was written test-first: the new case was run against the v2.0.0 code and failed before the fix.

| Fix | Before | Proof |
|---|---|---|
| `hooks/usage_counter.sh` stays silent when `python3` is missing | it exited 127 and printed an error into the session; it also needed `dirname`, which a bare `PATH` lacks | 3 launcher cases in `usage_counter_selftest.py`; 2 launcher mutants in `usage_counter_mutations.py` (9/9) |
| `install.sh --hooks` installs runtime hooks only | the counter's self-test and mutation scripts were copied into `~/.claude/hooks/` | CI's real-install step asserts they are absent; the same assertion fails on a v2.0.0 install |
| `scripts/usage_counts.py` reads the log the hook writes | a relative `evidence_dir` resolved against the working directory, so a report run from the toolkit clone read another project's log | `--project`, then `$CLAUDE_PROJECT_DIR`, then the working directory; 3 self-test cases, 2 mutants (10/10) |
| `tests/check_claims.py` reads two more kinds of version claim | a BibTeX `version = {X.Y.Z}` and a three-part `Status: vX.Y.Z` were not checked; it missed three stale 2.0.0 pins when VERSION moved to 2.0.1 | 3 self-test cases (one proves a two-part `Status: v2.0` is left alone), 3 mutants (17/17) |

---

## v2.0.2 Changelog (2026-10-20) — Run reports reach users

One defect, present since v1.1. Seven commands (`/audit`, `/commit`, `/dailysummary`, `/help`, `/improve`, `/runlog`, `/startup`) end by calling the run-report helper, six at `$TOOLKIT_ROOT/scripts/emit_run_report.sh` and one at `scripts/emit_run_report.sh`. Nothing defines `TOOLKIT_ROOT` for a user, and `install.sh` never copied the helper, so on a user's machine those calls found nothing: no `run_report.md`, no `run_log.csv` row, and `/runlog` had nothing from them to report. The CI install step did not notice, because it compared the number of installed commands to a typed 15.

**Re-run `install.sh` to receive this fix.**

### Added

| File | What it does |
|---|---|
| `scripts/emit_run_report.py` | The helper, ported to Python (standard library): the same arguments, the same 13-column row and `run_report.md` frontmatter. `install.sh` copies it to `~/.claude/toolkit/scripts/` in every mode (default, `--minimal`, `--hooks`) through a new `RUNTIME_SCRIPTS` array |
| `scripts/emit_run_report_selftest.py`, `scripts/emit_run_report_mutations.py` | 19 cases; 15 mutants, each turning its case red. Two cases and two mutants cover the `.sh` launcher: it finds the `.py` from any working folder, and with no `python3` on PATH it exits 0 and prints nothing |
| `tests/check_install.py`, `tests/check_install_mutations.py` | Real installs into temporary HOMEs in five modes, plus `--previous DIR` for an upgrade from an older checkout. Every expectation comes from `install.sh`'s arrays and from what the command files call. 20 cases; 17 mutants. Replaces the typed `-eq 15` step in `tests.yml` |
| `student/bootstrap.md`, Step 4b | The in-session installer (Claude copies the files with Read and Write) now installs the runtime scripts too, found from what the commands call. `check_install.py` fails if it loses that step |

### What it refuses

`check_install.py` exits 1 when: a command calls `$HOME/.claude/toolkit/scripts/<name>.py` and `<name>` is not in `RUNTIME_SCRIPTS`; a called script is absent after any install mode or after a re-install; the installed helper writes no row; a command calls `$TOOLKIT_ROOT` or a `scripts/` or `hooks/` path; a command runs `python3` without `Bash(python3:*)`; a command file is in neither command array; the installed commands differ from the arrays; a self-test or mutation file lands under `~/.claude`; `--hooks` leaves out a runtime hook; the PCV skill is missing; `--dry-run` writes a file; a re-install changes a `toolkit-config.md` the user filled in; after `--previous DIR`, an installed command is not the new version; or the installer exits non-zero.

### Proof it can fail

- Run against the released v2.0.1 tree, `check_install.py` reports all seven clone-path calls and exits 1. Against this tree it exits 0.
- `check_install.py --previous <clone at v2.0.1>` installs v2.0.1, fills in the config, then installs this tree: the helper is present, every command is the new version, and the config is byte-identical (exit 0).
- `check_helper_parity` (a one-off maintainer check, not shipped) ran the v2.0.1 shell helper and the Python helper on the same three argument sets, including a task summary with a comma and a double quote. The rows and frontmatter were identical except the model default, the timestamp and the run-dependent report path. With `model` removed from the allowed differences, the same check reported all six model differences and exited 1.

### Behaviour changes

- The seven commands call `python3 "$HOME/.claude/toolkit/scripts/emit_run_report.py"`. `scripts/emit_run_report.sh` stays as a launcher for the Python file, for anyone who calls it from a clone; no file was removed.
- The model column defaults to `unknown` instead of `claude-opus-4-7`. The helper cannot see which model ran; `$CLAUDE_MODEL` still sets it.
- Six commands (`audit`, `commit`, `dailysummary`, `help`, `runlog`, `startup`) gain `Bash(python3:*)` in `allowed-tools`; `improve` already had it. For `/runlog` this also covers its own CSV parser (`runlog.md:117` runs `python3`), which in v2.0.1 needed a permission prompt.
- The CSV append takes an `fcntl` lock with a 2-second wait. The shell helper used the `flock` command and appended with no lock where it was missing, which includes macOS. On a lock timeout the helper now writes no row, says so, and exits 0.

### Known gap, not fixed here

`/runlog` reads `evidence_dir` from `~/.claude/toolkit-config.md`, but only `/dailysummary` and `/startup` pass it to the helper. The other five write to `<project>/.toolkit/evidence`, so a user who changes `evidence_dir` will not see their rows in `/runlog`. The helper stays stateless (`scripts/README.md`, rule 2); the fix is for those five commands to pass `--evidence-dir`.

### What did NOT change

- The `run_log.csv` schema (13 columns) and the `run_report.md` frontmatter keys.
- No command was renamed and no argument was removed. In each command file only the helper call line and the `allowed-tools` line changed, plus, in `help.md`, the sentence that names the helper.
- The PCV bundle (`pcv/`) and the headline count (16 commands, `/pcv` included).

---

## v2.1.0 Changelog (2026-10-20) — Models by account

Before this release, six commands started subagents and only some named a model. `/pace`'s agents and the summary writers already requested Sonnet; `/coa`'s seats, Chair and rebuttal, `/review`'s lenses and `/readable`'s transcriber requested nothing and ran on the session's model, which defaults to Opus 5.5 on Pro, Max, Team, Enterprise and the Anthropic API (https://code.claude.com/docs/en/model-config, read 2026-10-20). Now every place a command starts an agent names its model, from one table keyed on the account the user gives `/setup`, and a gate fails the build if one does not.

### Added

| File | What it does |
|---|---|
| `shared/model-roles.json` | The role table: four roles (`reasoner`, `chair`, `writer`, `transcriber`), the model each requests on each account class, the sites each runs at, the account answers and their classes, and the recorded PCV agent models. Not installed: tools read it, the model does not |
| `references/model-roles.md` | The reasons, each with Anthropic's URL and the date it was read; the account classes as a cost policy; the Haiku admission test; the canonical MODEL FAILURE block; what the files cannot guarantee; where Anthropic's pages disagree; a dated appendix of what each alias resolved to. Every quotation on it was checked against the saved page text (33 quotes, 0 missing) |
| `tests/check_models.py`, `tests/check_models_mutations.py` | The model gate, classes M1 to M16 (docstring). 35 self-test cases, including four corpus controls on a copy of the real commands; 23 mutants |
| `tests/model_gate_triage.md` | The gate's Prior, committed before the gate existed, and the hand triage of its first run |
| `tests/smoke/model_gate_smoke.md` | The live check: `/tasks` after `/coa --quick` and `/pace` shows what each agent actually ran on |

`tests/check_claims.py` also derives "N command files" and "N slash command definitions", checks every "N planted defects" against the mutation file it names, bans "guarantees the model" and "always runs on", and is proven by 24 mutants (was 17).

### What it refuses

A spawn with no marker or no literal model; a marker whose model is not the table's for that role; `model=inherit`; a pinned full model ID outside the dated appendix and the changelogs; `fable` as a model value; `model:` in a command's own frontmatter; "best available model" and "Task tool"; a table with a missing cell, a writer on Haiku, Haiku on a role that has not passed the admission test, or a site with no marker; drift in the PCV agent models; a generated table or MODEL FAILURE copy that differs from its source; a crossmodel call outside an external block. A spawning command with no site at all is exit 2, never a pass.

### Proof it can fail

- **Prior before the run.** `tests/model_gate_triage.md` part 1 predicted 28 hit blocks, 12 role-site blocks with 7 naming a model, and the two role-sites the patterns could not see (the `/coa` rebuttal and the `/pace` revision reviewer). The first run found 32 blocks; the 12, the 7 and the two unseen sites matched exactly, and the 4 extra blocks are listed there.
- **Corpus controls.** On a copy of the real commands: deleting the literal at the `/pace` Player spawn exits 1 at that block; a `reasoner` marker changed to `opus` is refused; a spawn reworded past every pattern with its marker deleted is caught by the table's site list.
- **Mutation.** 23 mutants of the gate, one per class plus four the plan named (exit code ignored, the `pcv/` exemption widened, a spawning command with no site passing, matching line by line instead of by block); each turns its case red.

### Behaviour changes

- (a) `/coa` members, cross-check and rebuttal, `/review` lenses and the `/readable` transcriber stop inheriting the session model and request `sonnet`. On a default session that is a step down from Opus 5.5: Anthropic says Opus "costs several times more per turn than Sonnet" (https://support.claude.com/en/articles/14552983-models-usage-and-limits-in-claude-code, read 2026-10-20); the effect on what a council finds has not been measured.
- (b) The `/coa` Chair requests `model_chair` from `~/.claude/toolkit-config.md`: `opus` only for an opus-ceiling account whose `/model` lists Opus, otherwise `sonnet`.
- (c) **Existing installs keep their config** (the installer never overwrites it), so the Chair requests `sonnet` until the account question is answered. `/coa` asks it once at roster time; `/setup` asks it too.
- (d) New printed lines: `/coa`'s session report shows `requested: seats sonnet | chair <model>` and `second reader: …`; `/pace`'s declaration reads `requested 5 agents on sonnet`.
- (e) `/audit` and `/quarto` lose an `Agent` permission neither used.
- (f) The `/coa` stall row (`agent_stalls.csv`) gains a `model` column.
- (g) The five "use the best available model" fallbacks in `/pace`, `/dailysummary` and `/weeklysummary` are replaced by the MODEL FAILURE block: a command now stops and offers choices instead of switching a model on its own. The summaries keep their numeric re-check as one of the choices.
- (h) `/setup` asks one more question (the account), with a `/model` follow-up for opus-ceiling accounts, and reports, by name only, environment variables and settings that override the table. It gains `Bash(python3:*)` and `Bash(claude --version)`.

### What did NOT change

- No command was renamed and no flag was removed: every `--flag` and `argument-hint` line in the 11 changed command files was compared with v2.0.2 (0 dropped).
- The install surface: the role table and `references/` are not installed; the headline count is 16.
- The PCV bundle (`pcv/`) and its own agent models, which the gate compares but never edits.
- No role requests Haiku or Fable.

---

## v2.2.0 Changelog (2026-10-20) — Council, guards and workflow

One release, built from three that were planned separately: the `/coa` seats as installed agents, seven skills, a
command, four optional hooks, the account-aware model table extended to smaller plans, and a chatbot route for people
who do not use Claude Code. The headline count goes from 16 to 24; every count on every page is derived by
`tests/check_claims.py`.

### Added

| File | What it does |
|---|---|
| `coa/agents/coa-*.md` (5) and `coa/agents/addon/coa-*.md` (3) | The council seats. Every install copies the five general ones: `coa-skeptic`, `coa-practitioner`, `coa-economist`, `coa-advocate`, `coa-end-user`. `--addon-seats` adds `coa-historian`, `coa-editor`, `coa-paper-reviewer`. Each holds its seat's lens, required artifact and output structure, requests `sonnet` in its frontmatter and lists no `Agent` tool (gate class M8). A seat for one field is a persona file in `coa/personas/` |
| `shared/skills/quick-ten/` | `/quick-ten`: before a substantial build, the few questions (at most ten) whose answers change what gets built, a recap, and a brief the build follows |
| `shared/skills/guard-hook/`, `shared/skills/bulletproof/` | `/guard-hook` builds a hook guard and proves its self-test fails against a neutered copy (useful only to people who use hooks); `/bulletproof` puts tests behind new functionality and proves them by planting the defect each guard exists to prevent |
| `shared/skills/list-maker/`, `shared/skills/step-by-step/` | `/list-maker` turns a transcript, an email thread or notes into a numbered work list whose numbers never change; `/step-by-step` walks what a session changed, or works the list, one item per turn, and refuses to call a walkthrough done early |
| `shared/skills/automate/`, `shared/skills/meeting-breakdown/` | `/automate` turns a finished task into a skill with a tested script and a reproduction check; `/meeting-breakdown` breaks a transcript into a per-domain plan with a five-agent run (two agents on smaller plans) |
| `shared/commands/acquire.md`, `scripts/acquire.py` | `/acquire`: download a paper or a manifest, refuse HTML and a DOI that names another paper, extract with a density gate, grep-check every claimed figure. Needs `pypdf` or `PyMuPDF` |
| `scripts/check_transcription.py` | refuses a page transcription of a scanned PDF unless its pages and text pass six checks and, with two readers, both agree on every number, page by page. Ported from a checker first written for vision transcriptions |
| `hooks/_toolkit_config.py`, `hooks/protect_files` | the config reader the hooks share, and a guard that blocks a write to a `protected_files` entry (reading stays allowed; `NotebookEdit` included) |
| `scripts/register_hooks.py` | prints the `settings.json` block for the hooks you name, each unconditional; never edits a file |
| `scripts/check_coa_evidence_paths.py`, `scripts/check_heading_collisions.py`, `scripts/check_scratchpad_leak.py` | a `/coa` brief's paths resolve (a port of a Julia original, checked against its verdicts); two sibling sections with one title; files of value that exist only in a session scratchpad |
| `scripts/agent_stalls.py`, `scripts/headless_agent.py` | a ledger of subagent stalls; a stalled agent's prompt rerun as a restricted headless session that refuses `fable` and full model IDs |
| `shared/chatbot.json`, `scripts/render_chatbot_prompts.py` | a label for every command and skill (works in a chat, works with limits, Claude Code only) and the generator of the landing page's chatbot prompts; `--check` fails a command with no label or a site copy that is stale |
| `shared/pointers/` | one-release pointers at the old names `/dailysummary`, `/weeklysummary` and `/runlog` |

### Renamed

Command names of more than one word are hyphenated: `/daily-summary`, `/weekly-summary` and `/run-log` replace the
published `/dailysummary`, `/weeklysummary` and `/runlog`, which stay installed for this release as pointers that name
the new command; the next release removes them (Versioning Policy, above). The new skills ship hyphenated from the start.

### Smaller plans

On `pro`, `team-standard`, `unknown` or no answer: `/coa` defaults to the three-seat Quick Panel on Sonnet;
`/meeting-breakdown` runs one Player and one Coach; and page transcription (`/readable`, `/acquire`) runs on Haiku
with two readers whose results `check_transcription.py` must accept (`model_transcriber`, written by `/setup`). The
Haiku transcriber meets three of the four criteria of the Haiku admission test; the fourth, a logged run, is open and
stated in `references/model-roles.md`. A larger council or run is one request away.

### Changed

- **Hook policy.** The "project-specific safety hooks" rejection and Design Principle 5 are amended (above): a guard
  may ship as a mechanism with no list in it. `protect_files` is the one that does.
- **`token_budget_guard` and `summary_folder_guard` are now Python behind a launcher.** The token guard measured a
  prompt with `grep -o`, which stopped at the first quote; it now counts the whole prompt, keeps its total per session
  (by `session_id`), and keeps its state in `~/.claude/toolkit/state/`, not `/tmp/`. The folder guard matches whole
  path components, only for `.md` files.
- **The model gate** checks any config-keyed role's sentence, not only the Chair's, and treats `*_selftest.py` files
  as fixtures, like mutation files, because a self-test plants a refused model on purpose.

- **`/coa` v2.3.** A seat with an agent file starts on **Path A**: `subagent_type: "coa-<seat>"`, `model: "sonnet"`, and a prompt holding only the question brief and the seat's evidence. Any other seat (the Teacher, a specialist, a persona file, a seat whose file is missing) starts on **Path B**, the full template, as before. A failed Path A start falls back to Path B for that seat and says so. `session_summary.md` records each seat's path (`A`, `B`, `crossmodel:<model>`).
- **`install.sh`** gains `SKILLS` (full install only) and `SEAT_AGENTS` (every install). **Backups of a skill, PCV included, move out of `~/.claude/skills/`** to `~/.claude/toolkit-backups/<timestamp>/skills/`, because a backup folder holding a `SKILL.md` inside `skills/` could load as a second skill. When a skill shares a name with a command already in `~/.claude/commands/`, the installer prints one line and removes nothing: the skill takes precedence ("A skill and a file in .claude/commands/ … The skill", https://code.claude.com/docs/en/skills, read 2026-10-20).
- **`install.sh`** also gains `ADDON_SEATS` (`--addon-seats`), `OPTIONAL_HOOKS` and `HOOK_LIBS` (`--hooks`, never
  registered), and `POINTER_COMMANDS`; `RUNTIME_SCRIPTS` adds `check_coa_evidence_paths`, `acquire` and
  `check_transcription`.
- **`/coa`** checks each seat's evidence paths with a script before dispatch (Step 0b), gains `Bash(python3:*)`, and
  defaults to the Quick Panel on smaller plans.
- **`/readable`** starts its transcriber through `model_transcriber` and checks the result before installing it.
- **`/setup`** writes `model_transcriber`.
- **`student/bootstrap.md`** installs skills, seat agents and the scripts the skills call, and backs up PCV outside
  `skills/`; add-on seats only on request.
- **Versioning policy** (above): one approved list per release, with usage as evidence; a skill counts as a command; a
  rename keeps a pointer for one release.
- `/help`, the README and the proactive fragment list every new command and skill; the fragment has one rule for each
  command except `/setup`.
- **CI** runs every self-test and mutation check under `hooks/`, `scripts/` and the skills' `assets/` by glob, and the
  chatbot label check.

### Proof it can fail

- Across the seventeen new or rewritten tools: 512 self-test cases in 18 suites, every suite exits 0, and 211 mutants,
  every one caught. Each mutation file names the case it must turn red; `/step-by-step` instead removes each of its 10
  guards in turn and requires its case to change.
- `tests/check_install.py` covers skills, seats, add-on seats, hooks and pointers in six modes (default, `--minimal`,
  `--hooks`, `--addon-seats`, a re-install, `--dry-run`): 42 cases, 38 mutants.
- `tests/check_models.py`: 0 findings over 42 blocks (20 role markers, 0 unmarked); 39 cases, 25 mutants.
- Writing the tests found real defects before release: two dead alternatives in hook patterns; a config entry with a
  space matching a longer folder name; four self-tests that crashed on a mutant instead of failing a case; a test
  module that loaded a stale cached copy of an earlier mutant; and test fixtures a rename had turned into no-ops.
- **De-identification.** Every ported file was rewritten without project names, people, private folders or dated
  incidents, then checked by the private leak gate and the private-token scan.

### Behaviour changes

- `/coa` sends a Path A seat a shorter prompt; the lens comes from the agent file. On a smaller plan the default
  council is three seats.
- Page transcription runs on Haiku with two readers on smaller plans, and nothing is installed unless
  `check_transcription.py` passes.
- Re-installing over an older install leaves the PCV backup in `~/.claude/toolkit-backups/`, not inside
  `~/.claude/skills/`.
- `token_budget_guard`: the total resets per session, not per day.
- `summary_folder_guard`: notes only dated `.md` files, and `Daily Summary Archive/` no longer counts as
  `Daily Summary/`.
- `/coa` and `/acquire` run scripts, so they may ask once for `python3` permission.
- The install gate's mutation check takes about ten minutes, because every mutant re-runs real installs.

### What did NOT change

- No flag was removed. `--minimal` installs the same commands as before, plus the five seats.
- No hook is registered by any install mode, and no hook holds a list of its own.
- The PCV bundle is unchanged.
